import { LightningElement, api, wire } from 'lwc';
import FORM_FACTOR from '@salesforce/client/formFactor';
import { getObjectInfo, getPicklistValuesByRecordType } from 'lightning/uiObjectInfoApi';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import { loadStyle } from 'lightning/platformResourceLoader';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import Id from '@salesforce/user/Id';
import PROFILE_NAME from '@salesforce/schema/User.Profile.Name';

import INQUIRY_OBJECT from '@salesforce/schema/Inquiry__c';
import STATUS_FIELD from '@salesforce/schema/Inquiry__c.Status__c';
import SUB_FIELD from '@salesforce/schema/Inquiry__c.Sub_Status__c';
import RT_FIELD from '@salesforce/schema/Inquiry__c.RecordTypeId';
import CONTACT_FIELD from '@salesforce/schema/Inquiry__c.Contact__c';

import updateStatus from '@salesforce/apex/InquiryStatusPathController.updateStatus';
import getCallOutcomePicklistValues from '@salesforce/apex/InquiryLogCallController.getCallOutcomePicklistValues';
import createCallTask from '@salesforce/apex/InquiryLogCallController.createCallTask';

import benton from '@salesforce/resourceUrl/BentonSans';
import freight from '@salesforce/resourceUrl/FreightBigProBook3';

const SPECIAL_RTIDS = new Set(['012fh0000006hWvAAI', '012fh0000006hYXAAY']);

const DEFAULT_STATUS_SUB_MAP = {
  'new lead': [
    { value: 'Not Yet Contacted', label: 'Not Yet Contacted' },
    { value: 'Incorrect Details', label: 'Incorrect Details' },
    { value: 'Not Reachable', label: 'Not Reachable' },
    { value: 'Reassigned Lead', label: 'Reassigned Lead' }
  ],
  'engaged': [
    { value: 'Dormant', label: 'Dormant' },
    { value: 'High Activity', label: 'High Activity' },
    { value: 'Low Activity', label: 'Low Activity' },
    { value: 'Medium Activity', label: 'Medium Activity' }
  ],
  'viewing': [
    { value: '3+ Meetings', label: '3+ Meetings' },
    { value: 'Initial Meeting', label: 'Initial Meeting' },
    { value: 'Second Meeting', label: 'Second Meeting' },
    { value: 'Site Visit', label: 'Site Visit' }
  ],
  'offering': [
    { value: 'Request for Offer / RA Sent', label: 'Request for Offer / RA Sent' }
  ],
  'won': [
    { value: 'Linked to Closing', label: 'Linked to Closing' }
  ],
  'lost': [
    { value: 'Duplicate', label: 'Duplicate' },
    { value: 'Not Interested', label: 'Not Interested' },
    { value: 'Wrong Contact Information', label: 'Wrong Contact Information' }
  ]
};

const ALT_STATUS_SUB_MAP = {
  'engaged': [
    { value: 'Finding Property', label: 'Finding Property' },
    { value: 'Financing Pending', label: 'Financing Pending' }
  ],
  'offering': [
    { value: 'Under Offer/pending', label: 'Under Offer/pending' },
    { value: 'Offer Accepted / Deal Closed', label: 'Offer Accepted / Deal Closed' }
  ]
};

export default class InquiryStatusPath extends LightningElement {
  @api recordId;

  // PROFILE DETECTION
  userId = Id;
  profileName = '';
  isAdmin = false;
  showSubject = true;

  isDesktop = false;
  statusValues = [];
  selectedStatus = '';
  tempSelectedStatus = '';
  selectedSubStatus = '';
  tempSelectedSubStatus = '';
  subByStatus = {};
  showModal = false;
  showDrawer = false;
  isSaving = false;
  _hasScrolled = false;

  rtId;
  _recordRtId;
  _contactId;
  hasRecord = false;
  hasPicklists = false;

  callSubject = '';
  callOutcome = '';
  callComments = '';
  callOutcomeOptions = [{ label: 'Loading...', value: '' }];

  viewingStartDate = null;
  viewingStartTime = null;
  viewingEndDate = null;
  viewingEndTime = null;
  viewingLocation = '';

  // Handlers
  handleCallSubject(e) { this.callSubject = e.detail.value; }
  handleCallOutcome(e) { this.callOutcome = e.detail.value; }
  handleCallComments(e) { this.callComments = e.detail.value; }

  handleViewingStartDate(e) { this.viewingStartDate = e.detail.value; }
  handleViewingStartTime(e) { this.viewingStartTime = e.detail.value; }
  handleViewingEndDate(e) { this.viewingEndDate = e.detail.value; }
  handleViewingEndTime(e) { this.viewingEndTime = e.detail.value; }
  handleViewingLocation(e) { this.viewingLocation = e.detail.value; }

  get viewingDateTime() {
    if (this.viewingStartDate && this.viewingStartTime) {
      try {
        const d = new Date(`${this.viewingStartDate}T${this.viewingStartTime}`);
        if (isNaN(d.getTime())) return null;
        return d.toISOString();
      } catch {
        return null;
      }
    }
    return null;
  }

  get isSpecialRt() {
    const id = this._recordRtId || this.rtId;
    return !!id && SPECIAL_RTIDS.has(id);
  }
  get effectiveStatusSubMap() {
    return this.isSpecialRt ? ALT_STATUS_SUB_MAP : DEFAULT_STATUS_SUB_MAP;
  }
  get isSubDisabled() {
    const k = (this.tempSelectedStatus || this.selectedStatus || '').trim().toLowerCase();
    return (this.subByStatus[k] || []).length === 0;
  }
  get isSubRequired() {
    const k = (this.tempSelectedStatus || this.selectedStatus || '').trim().toLowerCase();
    return (this.subByStatus[k] || []).length > 0;
  }
  get subOptionsWithNone() {
    const k = (this.tempSelectedStatus || this.selectedStatus || '').trim().toLowerCase();
    return (this.subByStatus[k] || []).map(o => ({
      value: o.value,
      label: this.cleanSubLabel(o.label || o.value)
    }));
  }
  get isViewing() {
    const k = (this.tempSelectedStatus || this.selectedStatus || '').trim().toLowerCase();
    return k === 'viewing';
  }

  @wire(getObjectInfo, { objectApiName: INQUIRY_OBJECT })
  wiredObj({ data }) {
    if (data && !this._recordRtId && !this.rtId) {
      this.rtId = data.defaultRecordTypeId;
    }
  }

  @wire(getRecord, { recordId: '$recordId', fields: [STATUS_FIELD, SUB_FIELD, RT_FIELD, CONTACT_FIELD] })
  wiredRecord({ data }) {
    if (!data) return;
    this._recordRtId = getFieldValue(data, RT_FIELD);
    this._contactId = getFieldValue(data, CONTACT_FIELD);
    this.selectedStatus = getFieldValue(data, STATUS_FIELD) || '';
    this.selectedSubStatus = getFieldValue(data, SUB_FIELD) || '';
    if (this._recordRtId) this.rtId = this._recordRtId;
    this.hasRecord = true;
    this.syncActiveOnce();
    this.updateProgressLine();
  }

  @wire(getPicklistValuesByRecordType, { objectApiName: INQUIRY_OBJECT, recordTypeId: '$rtId' })
  wiredPicklists({ data }) {
    if (!data) return;
    const statusPFV = data.picklistFieldValues[STATUS_FIELD.fieldApiName];
    const subPFV = data.picklistFieldValues[SUB_FIELD.fieldApiName];

    const statusVals = statusPFV?.values ?? [];
    this.statusValues = statusVals.map(s => ({
      label: s.label || s.value,
      value: s.value,
      className: this.computeClass(s.value),
      ariaSelected: s.value === this.selectedStatus ? 'true' : 'false'
    }));

    const subVals = subPFV?.values ?? [];
    const ctrlIndexMap = subPFV?.controllerValues ?? {};
    const hasDependency = Object.keys(ctrlIndexMap).length > 0;

    const depMap = {};
    const map = this.effectiveStatusSubMap;

    statusVals.forEach(s => {
      const statusValue = (s.value || '').trim();
      const normalizedKey = statusValue.toLowerCase();

      if (hasDependency && ctrlIndexMap[statusValue] !== undefined) {
        const idx = ctrlIndexMap[statusValue];
        let allowed = subVals
          .filter(sub => this.isValidFor(sub.validFor, idx))
          .map(sub => ({ value: sub.value, label: sub.label || sub.value }));
        depMap[normalizedKey] = allowed.length > 0 ? allowed : (map[normalizedKey] || []);
      } else {
        depMap[normalizedKey] = map[normalizedKey] || [];
      }
    });

    this.subByStatus = depMap;
    this.hasPicklists = true;
    this.syncActiveOnce();
    this.updateProgressLine();
  }

  // PROFILE WIRE
  @wire(getRecord, { recordId: '$userId', fields: [PROFILE_NAME] })
  wiredUser({ error, data }) {
    if (data) {
      this.profileName = getFieldValue(data, PROFILE_NAME) || '';
      this.isAdmin = this.profileName === 'Exclusive Project Admin';
      this.showSubject = this.profileName !== 'Sales Agent'; // Hide subject for agents
    } else if (error) {
      console.error('Failed to load user profile', error);
    }
  }

  connectedCallback() {
    this.isDesktop = FORM_FACTOR === 'Large';
    Promise.all([
      loadStyle(this, `${benton}/fonts.css`),
      loadStyle(this, `${freight}/fonts.css`)
    ]).catch(() => {});

    getCallOutcomePicklistValues()
      .then(data => {
        if (Array.isArray(data) && data.length > 0) {
          this.callOutcomeOptions = data.map(v => ({ label: v, value: v }));
        } else {
          this.callOutcomeOptions = [{ label: 'No options available', value: '' }];
        }
      })
      .catch(err => {
        console.error('Call Outcome fetch error:', err);
        this.callOutcomeOptions = [{ label: 'Unavailable', value: '' }];
      });
  }

  cleanSubLabel(label) {
    if (!label) return '';
    const parts = String(label).split('→');
    return parts[parts.length - 1].trim();
  }

  isValidFor(validFor, idx) {
    if (idx == null || idx < 0) return false;
    if (!validFor && validFor !== 0) return false;
    if (Array.isArray(validFor)) return validFor.includes(idx);
    if (validFor instanceof Uint8Array) {
      const byte = validFor[Math.floor(idx / 8)];
      return byte != null && ((byte >> (idx % 8)) & 1) === 1;
    }
    try {
      const bin = atob(validFor || '');
      const pos = Math.floor(idx / 8);
      if (pos < 0 || pos >= bin.length) return false;
      const byte = bin.charCodeAt(pos);
      return ((byte >> (idx % 8)) & 1) === 1;
    } catch {
      return false;
    }
  }

  computeClass(statusValue) {
    return `status-step ${statusValue === this.selectedStatus ? 'active' : ''}`;
  }

  refreshTileClasses() {
    this.statusValues = this.statusValues.map(s => ({
      ...s,
      className: this.computeClass(s.value),
      ariaSelected: s.value === this.selectedStatus ? 'true' : 'false'
    }));
  }

  syncActiveOnce() {
    if (!(this.hasRecord && this.hasPicklists)) return;
    this.refreshTileClasses();
    if (!this._hasScrolled) this._hasScrolled = true;
  }

  updateProgressLine() {
    if (!this.statusValues || this.statusValues.length === 0) return;
    const currentIndex = this.statusValues.findIndex(s => s.value === this.selectedStatus);
    if (currentIndex >= 0) {
      const progressPercent = ((currentIndex + 1) / this.statusValues.length) * 100;
      const container = this.template.querySelector('.status-tile-scroll');
      if (container) container.style.setProperty('--progress', progressPercent);
    }
  }

  async handleStepClick(e) {
    if (!this.hasPicklists) return;
    this.tempSelectedStatus = e.currentTarget.dataset.value || '';
    this.tempSelectedSubStatus = '';
    this.showModal = !this.isDesktop;
    this.showDrawer = this.isDesktop;
    document.body.style.overflow = 'hidden';
  }

  handleCancel() {
    this.showModal = false;
    this.showDrawer = false;
    document.body.style.overflow = '';
  }

  handleSubChange(e) {
    this.tempSelectedSubStatus = e.detail.value || '';
    this.validateSubStatus();
  }

  validateSubStatus() {
    const k = (this.tempSelectedStatus || this.selectedStatus || '').trim().toLowerCase();
    const hasOptions = (this.subByStatus[k] || []).length > 0;
    const v = this.tempSelectedSubStatus;
    const el = this.template.querySelector('.substatus-combobox');
    if (!el) return true;
    if (hasOptions && !v) {
      el.setCustomValidity('Please choose a Sub-Status.');
      el.reportValidity();
      return false;
    }
    el.setCustomValidity('');
    el.reportValidity();
    return true;
  }

  async handleModalSave() {
    if (!this.validateSubStatus()) {
      this.showToast('Missing Sub-Status', 'Please choose a Sub-Status.', 'warning');
      return;
    }

    if (!this.isViewing) {
      const missing = [];
      if (this.showSubject && !this.callSubject) missing.push('Subject');
      if (!this.callOutcome) missing.push('Call Outcome');
      if (missing.length > 0) {
        this.showToast(
          'Incomplete Call Log',
          `Please fill the following before saving: ${missing.join(', ')}`,
          'error'
        );
        return;
      }
    }

    this.isSaving = true;
    try {
      await updateStatus({
        inquiryId: this.recordId,
        newStatus: this.tempSelectedStatus,
        newSubStatus: this.tempSelectedSubStatus || null,
        lostReason: null,
        searchReason: null,
        viewingDateTime: this.viewingDateTime || null,
        viewingLocation: this.viewingLocation || null
      });

      if (!this.isViewing) {
        await createCallTask({
          whoId: this._contactId,
          subject: this.callSubject,
          comments: this.callComments,
          callOutcome: this.callOutcome,
          whatId: this.recordId
        });
      }

      this.selectedStatus = this.tempSelectedStatus;
      this.selectedSubStatus = this.tempSelectedSubStatus || '';
      this.refreshTileClasses();
      this.updateProgressLine();

      this.showModal = false;
      this.showDrawer = false;
      document.body.style.overflow = '';

      this.showToast('Success', 'Status and Call Log saved successfully.', 'success');
    } catch (err) {
      console.error('Save failed:', err);
      this.showToast('Error', this.errMsg(err) || 'Update failed', 'error');
    } finally {
      this.isSaving = false;
    }
  }

  showToast(title, message, variant) {
    this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
  }

  errMsg(e) {
    return e?.body?.message || e?.message || 'Unknown error';
  }
}