import { LightningElement, track } from 'lwc';
import getAllAgents from '@salesforce/apex/ProjectAgentController.getAllAgents';
import getAllProjects from '@salesforce/apex/ProjectAgentController.getAllProjects';
import searchProjectsByName from '@salesforce/apex/ProjectAgentController.searchProjectsByName';
import assignAgentToProject from '@salesforce/apex/ProjectAgentController.assignAgentToProject';
import getNextAgentId from '@salesforce/apex/ProjectAgentController.getNextAgentId';
import getProjectAgentMap from '@salesforce/apex/ProjectAgentController.getProjectAgentMap';
import getProjectAssignmentReport from '@salesforce/apex/ProjectAgentController.getProjectAssignmentReport';
import getAllCommunities from '@salesforce/apex/ProjectAgentController.getAllCommunities';
import searchCommunitiesByName from '@salesforce/apex/ProjectAgentController.searchCommunitiesByName';
import assignAgentToCommunity from '@salesforce/apex/ProjectAgentController.assignAgentToCommunity';
import getNextCommunityAgentId from '@salesforce/apex/ProjectAgentController.getNextCommunityAgentId';
import getCommunityAgentMap from '@salesforce/apex/ProjectAgentController.getCommunityAgentMap';
import getCommunityLocationFilters from '@salesforce/apex/ProjectAgentController.getCommunityLocationFilters';
import getCommunityLocationPicklistValues from '@salesforce/apex/ProjectAgentController.getCommunityLocationPicklistValues';
import getRegionsByCountry from '@salesforce/apex/ProjectAgentController.getRegionsByCountry';

import { ShowToastEvent } from 'lightning/platformShowToastEvent';

const showError = (error, defaultMessage) => {
    console.error('Error:', error);
    return error.body ? error.body.message : defaultMessage;
};

export default class ProjectAgentRotation extends LightningElement {
    @track projects = { data: [], loading: true, empty: false };
    @track pagedProjects = [];
    @track communities = { data: [], loading: false, empty: false };
    @track pagedCommunities = [];
    @track agentOptions = [];
    @track searchKey = '';
    @track areaSearchKey = '';
    @track assignmentReport = [];
    @track projectAgentMap = [];
    @track communityAgentMap = [];
    
    // Pagination properties for Projects
    @track currentPage = 1;
    @track pageSize = 5;
    @track totalProjects = 0;

    // Pagination properties for Communities
    @track communityCurrentPage = 1;
    @track totalCommunities = 0;
    
    @track showMainPage = true;
    @track showAssignedAgentsPage = false;
    @track showAreaAssignmentPage = false;
    
    @track showRotationModal = false;
    @track showCommunityRotationModal = false;
    @track selectedRotationProjectId = '';
    @track selectedRotationCommunityId = '';
    @track selectedCountry = '';
    @track selectedRegion = '';
    @track selectedSubRegion = '';

    @track countryOptions = [];
    @track regionOptions = [];
    @track subRegionOptions = [];
    
    assignmentReportColumns = [
        { label: 'Project Name', fieldName: 'ProjectName', type: 'text', sortable: true },
        { label: 'Agent Name', fieldName: 'AgentName', type: 'text', sortable: true },
        {
            label: 'Assigned On',
            fieldName: 'AssignedDate',
            type: 'date',
            typeAttributes: { year: 'numeric', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false },
            sortable: true
        }
    ];

    get projectOptions() {
        return this.projects.data.map(proj => ({ label: proj.Name, value: proj.Id }));
    }
    
    get communityOptions() {
        return this.communities.data.map(comm => ({ 
            label: comm.Name, 
            value: comm.Id 
        }));
    }
    
    get hasAssignmentReport() {
        return this.assignmentReport && this.assignmentReport.length > 0;
    }

    get hasProjectAgentMap() {
        return this.projectAgentMap && this.projectAgentMap.length > 0;
    }

    get hasCommunityAgentMap() {
        return this.communityAgentMap && this.communityAgentMap.length > 0;
    }

    // Pagination getters for Projects
    get totalPages() {
        return Math.ceil(this.totalProjects / this.pageSize);
    }

    get isFirstPage() {
        return this.currentPage === 1;
    }

    get isLastPage() {
        return this.currentPage >= this.totalPages;
    }

    get hasPagination() {
        return this.totalProjects > this.pageSize;
    }

    // Pagination getters for Communities
    get communityTotalPages() {
        return Math.ceil(this.totalCommunities / this.pageSize);
    }

    get isCommunityFirstPage() {
        return this.communityCurrentPage === 1;
    }

    get isCommunityLastPage() {
        return this.communityCurrentPage >= this.communityTotalPages;
    }

    get hasCommunityPagination() {
        return this.totalCommunities > this.pageSize;
    }

    // Open community rotation modal
    openAreaRotationModal(event) {
        this.showCommunityRotationModal = true;
        const communityId = event.currentTarget.dataset.id;
        this.selectedRotationCommunityId = communityId;
    }

    handleCommunitySelection(event) {
        this.selectedRotationCommunityId = event.detail.value;
    }

    closeModal() {
        this.showRotationModal = false;
        this.showCommunityRotationModal = false;
        this.selectedRotationProjectId = '';
        this.selectedRotationCommunityId = '';
    }

    // Handler for community rotation confirmation
    async handleConfirmCommunityRotation() {
        if (!this.selectedRotationCommunityId) {
            this.showToast('Error', 'Please select a community to rotate.', 'error');
            return;
        }

        try {
            this.showToast('Info', 'Rotating agent...', 'info');
            const agentId = await getNextCommunityAgentId();
            if (!agentId) {
                this.showToast('Error', 'No agents available for rotation.', 'error');
                this.closeModal();
                return;
            }

            await assignAgentToCommunity({
                communityId: this.selectedRotationCommunityId,
                agentId
            });

            this.showToast('Success', 'Agent rotated successfully', 'success');

            // Update the UI to reflect the new assignment
            this.communities.data = this.communities.data.map(comm =>
                comm.Id === this.selectedRotationCommunityId
                    ? { ...comm, selectedAgentId: agentId }
                    : comm
            );

            await this.loadCommunityAgentMap();
        } catch (error) {
            const message = showError(error, 'Rotation failed');
            this.showToast('Error', message, 'error');
        } finally {
            this.closeModal();
        }
    }

    connectedCallback() {
        this.loadInitialData();
        this.loadLocationFilters();
    }

    async refreshData() {
        this.showToast('Info', 'Refreshing data...', 'info');
        this.searchKey = '';
        this.currentPage = 1;
        await this.loadInitialData();
        this.showToast('Success', 'Data refreshed successfully!', 'success');
    }

    async loadInitialData() {
        try {
            await Promise.all([
                this.loadAgents(),
                this.loadProjects(),
                this.loadAssignmentReport(),
                this.loadProjectAgentMap()
            ]);
        } catch (error) {
            this.showToast('Error', 'Failed to load initial data', 'error');
        }
    }

    loadLocationFilters() {
        getCommunityLocationPicklistValues()
        .then(result => {
            if (result) {
                this.countryOptions = result.countries.map(item => ({ label: item, value: item }));
                this.regionOptions = result.regions.map(item => ({ label: item, value: item }));
                this.subRegionOptions = result.subRegions.map(item => ({ label: item, value: item }));
            }
        })
        .catch(error => {
            console.error('Error loading location filters:', error);
            this.showToast('Error', 'Failed to load location picklist values.', 'error');
        });
    }

    async loadAgents() {
        try {
            const agents = await getAllAgents();
            this.agentOptions = agents.map(agent => ({ label: agent.Name, value: agent.Id }));
        } catch (error) {
            const message = showError(error, 'Failed to load agents');
            this.showToast('Error', message, 'error');
        }
    }

    async loadProjects() {
        try {
            this.projects.loading = true;
            const result = this.searchKey ? await searchProjectsByName({ nameFilter: this.searchKey }) : await getAllProjects();
            
            this.projects.data = result.map(proj => ({ ...proj, selectedAgentId: '' }));
            this.totalProjects = this.projects.data.length;
            this.currentPage = 1;
            this.updatePagedProjects();

            this.projects.loading = false;
            this.projects.empty = result.length === 0;
            
        } catch (error) {
            const message = showError(error, 'Failed to load projects');
            this.showToast('Error', message, 'error');
            this.projects.loading = false;
        }
    }

    updatePagedProjects() {
        const start = (this.currentPage - 1) * this.pageSize;
        const end = this.currentPage * this.pageSize;
        this.pagedProjects = this.projects.data.slice(start, end);
    }
    
    handlePreviousPage() {
        if (this.currentPage > 1) {
            this.currentPage--;
            this.updatePagedProjects();
        }
    }

    handleNextPage() {
        if (this.currentPage < this.totalPages) {
            this.currentPage++;
            this.updatePagedProjects();
        }
    }

    async loadProjectAgentMap() {
        try {
            const result = await getProjectAgentMap();
            this.projectAgentMap = Object.keys(result).map(projectName => ({ projectName, agents: result[projectName] }));
        } catch (error) {
            const message = showError(error, 'Failed to load project-agent map');
            console.error('Error loading project-agent map:', message);
        }
    }

    async loadAssignmentReport() {
        try {
            const data = await getProjectAssignmentReport();
            this.assignmentReport = data.map(row => ({
                Id: row.Id,
                ProjectName: row.Project__r?.Name || 'Unknown Project',
                AgentName: row.Agent__r?.Name || 'Unassigned',
                AssignedDate: row.CreatedDate
            }));
        } catch (error) {
            const message = showError(error, 'Failed to load assignment report');
            console.error('Error loading assignment report:', message);
        }
    }
    
    openAreaAssignmentPage() {
        this.showMainPage = false;
        this.showAssignedAgentsPage = false;
        this.showAreaAssignmentPage = true;
        this.communityCurrentPage = 1;
        this.loadCommunities();
        this.loadCommunityAgentMap();
    }

    goBackToMainPage() {
        this.showMainPage = true;
        this.showAssignedAgentsPage = false;
        this.showAreaAssignmentPage = false;
    }

    handleAreaSearchChange(event) {
        this.areaSearchKey = event.target.value;
        clearTimeout(this.areaDelayTimeout);
        this.areaDelayTimeout = setTimeout(() => {
            this.communityCurrentPage = 1;
            this.loadCommunities();
        }, 300);
    }
    
    async loadCommunities() {
        try {
            this.communities.loading = true;
            const result = this.areaSearchKey ? await searchCommunitiesByName({ nameFilter: this.areaSearchKey }) : await getAllCommunities();
            
            this.communities.data = result.map(comm => ({ ...comm, selectedAgentId: '' }));
            this.totalCommunities = this.communities.data.length;
            this.updatePagedCommunities();

            this.communities.loading = false;
            this.communities.empty = result.length === 0;
            
        } catch (error) {
            const message = showError(error, 'Failed to load communities');
            this.showToast('Error', message, 'error');
            this.communities.loading = false;
        }
    }

    // New event handlers for picklists
    handleCountryChange(event) {
        this.selectedCountry = event.detail.value;
        this.selectedRegion = '';
        this.regionOptions = [];
        this.selectedSubRegion = '';
        this.subRegionOptions = [];
        this.filterCommunities();
        this.getRegionsForCountry(this.selectedCountry);
    }

    handleRegionChange(event) {
        this.selectedRegion = event.detail.value;
        this.selectedSubRegion = '';
        this.filterCommunities();
    }

    handleSubRegionChange(event) {
        this.selectedSubRegion = event.detail.value;
        this.filterCommunities();
    }
    
    async getRegionsForCountry(country) {
        if (!country) {
            return;
        }
        try {
            const result = await getRegionsByCountry({ country: country });
            this.regionOptions = result.map(item => ({ label: item, value: item }));
        } catch (error) {
            console.error('Error fetching regions:', error);
        }
    }
    
    // New function to filter communities based on selected picklist values
    async filterCommunities() {
        try {
            this.communities.loading = true;
            const filters = {
                country: this.selectedCountry,
                region: this.selectedRegion,
                subRegion: this.selectedSubRegion
            };
            
            const result = await getCommunityLocationFilters({ filters: filters });
            
            this.communities.data = result.map(comm => ({ ...comm, selectedAgentId: '' }));
            this.totalCommunities = this.communities.data.length;
            this.updatePagedCommunities();
            
            this.communities.loading = false;
            this.communities.empty = result.length === 0;
        } catch (error) {
            const message = showError(error, 'Failed to filter communities');
            this.showToast('Error', message, 'error');
            this.communities.loading = false;
        }
    }

    updatePagedCommunities() {
        const start = (this.communityCurrentPage - 1) * this.pageSize;
        const end = this.communityCurrentPage * this.pageSize;
        this.pagedCommunities = this.communities.data.slice(start, end);
    }
    
    handleCommunityPreviousPage() {
        if (this.communityCurrentPage > 1) {
            this.communityCurrentPage--;
            this.updatePagedCommunities();
        }
    }

    handleCommunityNextPage() {
        if (this.communityCurrentPage < this.communityTotalPages) {
            this.communityCurrentPage++;
            this.updatePagedCommunities();
        }
    }

    async loadCommunityAgentMap() {
        try {
            const result = await getCommunityAgentMap();
            this.communityAgentMap = Object.keys(result).map(communityName => ({ communityName, agents: result[communityName] }));
        } catch (error) {
            const message = showError(error, 'Failed to load community-agent map');
            console.error('Error loading community-agent map:', message);
        }
    }

    handleAreaAgentChange(event) {
        const communityId = event.target.dataset.id;
        const selectedAgentId = event.detail.value;
        this.communities.data = this.communities.data.map(community =>
            community.Id === communityId ? { ...community, selectedAgentId } : community
        );
    }
    
    async handleAreaAssign(event) {
        const communityId = event.target.dataset.id;
        const community = this.communities.data.find(c => c.Id === communityId);
        if (!community?.selectedAgentId) {
            this.showToast('Error', 'Please select an agent before assigning.', 'error');
            return;
        }
        try {
            this.showToast('Info', 'Assigning agent...', 'info');
            await assignAgentToCommunity({ communityId: communityId, agentId: community.selectedAgentId });
            this.showToast('Success', 'Agent assigned successfully', 'success');
            await this.loadCommunityAgentMap();
        } catch (error) {
            const message = showError(error, 'Assignment failed');
            this.showToast('Error', message, 'error');
        }
    }

    handleSearchChange(event) {
        this.searchKey = event.target.value;
        clearTimeout(this.delayTimeout);
        this.delayTimeout = setTimeout(() => {
            this.loadProjects();
        }, 300);
    }

    handleAgentChange(event) {
        const projectId = event.target.dataset.id;
        const selectedAgentId = event.detail.value;
        this.projects.data = this.projects.data.map(project =>
            project.Id === projectId ? { ...project, selectedAgentId } : project
        );
    }

    async handleAssign(event) {
        const projectId = event.target.dataset.id;
        const project = this.projects.data.find(p => p.Id === projectId);
        if (!project?.selectedAgentId) {
            this.showToast('Error', 'Please select an agent before assigning.', 'error');
            return;
        }
        try {
            this.showToast('Info', 'Assigning agent...', 'info');
            await assignAgentToProject({ projectId: projectId, agentId: project.selectedAgentId });
            this.showToast('Success', 'Agent assigned successfully', 'success');
            await Promise.all([this.loadAssignmentReport(), this.loadProjectAgentMap()]);
        } catch (error) {
            const message = showError(error, 'Assignment failed');
            this.showToast('Error', message, 'error');
        }
    }

    openRotationModal(event) {
        this.selectedRotationProjectId = event.currentTarget.dataset.id;
        this.showRotationModal = true;
    }

    handleProjectSelection(event) {
        this.selectedRotationProjectId = event.detail.value;
    }

    async handleConfirmRotation() {
        if (!this.selectedRotationProjectId) {
            this.showToast('Error', 'Please select a project to rotate.', 'error');
            return;
        }
        try {
            this.showToast('Info', 'Rotating agent...', 'info');
            const agentId = await getNextAgentId();
            if (!agentId) {
                this.showToast('Error', 'No agents available for rotation.', 'error');
                this.closeModal();
                return;
            }
            await assignAgentToProject({ projectId: this.selectedRotationProjectId, agentId });
            this.showToast('Success', 'Agent rotated successfully', 'success');
            this.projects.data = this.projects.data.map(project =>
                project.Id === this.selectedRotationProjectId ? { ...project, selectedAgentId: agentId } : project
            );
            await Promise.all([this.loadAssignmentReport(), this.loadProjectAgentMap()]);
        } catch (error) {
            const message = showError(error, 'Rotation failed');
            this.showToast('Error', message, 'error');
        } finally {
            this.closeModal();
        }
    }

    openAssignedAgentsPage() {
        this.showMainPage = false;
        this.showAssignedAgentsPage = true;
        this.loadProjectAgentMap();
    }
    
    exportToExcel() {
        if (!this.hasProjectAgentMap) {
            this.showToast('Error', 'No assigned agents to export.', 'error');
            return;
        }
        const data = this.projectAgentMap.flatMap(item =>
            item.agents.map(agentName => ({ 'Project Name': item.projectName, 'Agent Name': agentName }))
        );
        const headers = ['Project Name', 'Agent Name'];
        let csvContent = headers.join(',') + '\n';
        data.forEach(row => {
            const rowData = headers.map(header => `"${row[header]}"`).join(',');
            csvContent += rowData + '\n';
        });
        const encodedUri = encodeURI('data:text/csv;charset=utf-8,' + csvContent);
        const link = document.createElement('a');
        link.setAttribute('href', encodedUri);
        link.setAttribute('download', 'agents_by_project.csv');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    showToast(title, message, variant) {
        this.dispatchEvent(
            new ShowToastEvent({
                title,
                message,
                variant
            })
        );
    }
}