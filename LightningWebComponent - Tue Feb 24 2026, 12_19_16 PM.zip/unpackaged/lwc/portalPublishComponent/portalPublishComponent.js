import { LightningElement, wire, track, api } from 'lwc';
import getPortalsByRegion from '@salesforce/apex/PortalController.getPortalsByRegion';
import publishUnpublishListing from '@salesforce/apex/PortalController.publish_Or_Unpublish';
import fetchPropertyMedia from '@salesforce/apex/PortalController.fetchPropertyMedia';
import publishOnPropertyFinder from '@salesforce/apex/PropertyFinderCreateListingService.createListing';
import unpublishOnPropertyFinder from '@salesforce/apex/PropertyFinderUnpublishService.unpublishListing';
import checkUserProfile from '@salesforce/apex/PortalController.checkUserProfile';
import { refreshApex } from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class PortalPublishComponent extends LightningElement {
    @api recordId;

    @track portalData = [];
    @track filteredPortalData = [];
    @track summary = { total: 0, published: 0, unpublished: 0 };
    @track mediaCheckMessage = '';

    isLoading = true;
    showActions = false;
    wiredPortalData;

    /* ==============================
       WIRE METHODS
    ============================== */

    @wire(checkUserProfile)
    wiredProfile({ data, error }) {
        if (data !== undefined) {
            this.showActions = data;
            // Recalculate button states after profile check
            this.portalData = this.formatPortalData(this.portalData);
            this.filteredPortalData = [...this.portalData];
        } else if (error) {
            console.error('Error fetching profile:', error);
            this.showActions = false;
        }
    }

    @wire(fetchPropertyMedia, { listingId: '$recordId' })
    wiredMedia({ data, error }) {
        if (data) {
            this.mediaCheckMessage = data;
            // Recalculate button states once media is fetched
            this.portalData = this.formatPortalData(this.portalData);
            this.filteredPortalData = [...this.portalData];
        } else if (error) {
            console.error('Error fetching media:', error);
        }
    }

    @wire(getPortalsByRegion, { recordId: '$recordId' })
    wiredPortals(result) {
        this.wiredPortalData = result;
        this.isLoading = true;

        if (result.data) {
            this.portalData = this.formatPortalData(result.data);
            this.filteredPortalData = [...this.portalData];
            this.updateSummaryCounts();
        } else if (result.error) {
            console.error('Error fetching portals:', result.error);
        }

        this.isLoading = false;
    }

    /* ==============================
       DATA HANDLING
    ============================== */

    updateSummaryCounts() {
        const publishedCount = this.portalData.filter(p => p.isPublishedOnPortal).length;
        this.summary = {
            total: this.portalData.length,
            published: publishedCount,
            unpublished: this.portalData.length - publishedCount
        };
    }

    formatDate(value) {
    // Ensure that the value is not null or undefined
    if (!value) {
        return '—'; // Return the placeholder when the date is not available
    }

    // Format the date if it's valid
    return new Date(value).toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
    });
}



    formatPortalData(data) {
        return data.map(portal => {
            const isPublished = portal.isPublishedOnPortal === true;

            // BUTTON LOGIC
            const baseDisabled = !this.showActions || portal.portalStatus !== 'Active';
            const isPublishDisabled = isPublished || baseDisabled || this.mediaCheckMessage !== 'Listing has media';
            const isUnpublishDisabled = !isPublished || baseDisabled;

            // Debugging the date values
            console.log('portal.publishedDate:', portal.publishedDate);
            console.log('portal.withdrawnDate:', portal.withdrawnDate);

            // Ensure that the dates are properly formatted
            const formattedPublishedDate = this.formatDate(portal.publishedDate);
            const formattedWithdrawnDate = this.formatDate(portal.withdrawnDate);

            return {
                ...portal,
                isPublishDisabled,
                isUnpublishDisabled,
                currentStatusDisplay: isPublished ? 'Published' : 'Unpublished',
                lastPublished: formattedPublishedDate,
                withdrawnDate: formattedWithdrawnDate,
                publishedStatusClass: isPublished ? 'status-published' : 'status-unpublished'
            };
        });
    }

    /* ==============================
       SEARCH
    ============================== */

    handleSearch(event) {
        const term = event ? event.target.value.toLowerCase() : '';
        this.filteredPortalData = !term
            ? this.portalData
            : this.portalData.filter(p => p.portalName.toLowerCase().includes(term));
    }

    /* ==============================
       BUTTON ACTION
    ============================== */

    async handleButtonClick(event) {
        const portalId = event.target.dataset.id;
        const portal = this.portalData.find(p => p.portalId === portalId);
        if (!portal) return;

        const isPublishing = !portal.isPublishedOnPortal;

        // MEDIA CHECK
        if (isPublishing && this.mediaCheckMessage !== 'Listing has media') {
            this.showToast(this.mediaCheckMessage, 'warning');
            return;
        }

        this.isLoading = true;

        try {
            if (portal.portalName === 'Property Finder') {
                const pfResult = isPublishing
                    ? await publishOnPropertyFinder({ listingId: this.recordId })
                    : await unpublishOnPropertyFinder({ listingId: this.recordId });

                if (pfResult !== 'success') {
                    throw new Error(pfResult || 'Property Finder API failed');
                }
            }

            await publishUnpublishListing({
                listingId: this.recordId,
                portalName: portal.portalName,
                isPublished: isPublishing
            });

            await refreshApex(this.wiredPortalData);

            this.showToast(
                `${portal.portalName} ${isPublishing ? 'Published' : 'Unpublished'} successfully`,
                'success'
            );

        } catch (error) {
            console.error('Publish/Unpublish error:', error);
            this.showToast(error.body?.message || error.message || 'Operation failed', 'error');
        } finally {
            this.isLoading = false;
        }
    }

    /* ==============================
       TOAST
    ============================== */

    showToast(message, variant) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: variant === 'success' ? 'Success' : 'Error',
                message,
                variant
            })
        );
    }
}