import { LightningElement, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { loadStyle } from 'lightning/platformResourceLoader';

// Static resources (fonts + art)
import benton from '@salesforce/resourceUrl/BentonSans';
import freight from '@salesforce/resourceUrl/FreightBigProBook3';
import listingPanel from '@salesforce/resourceUrl/ListingPanel';
import defaultThumbnail from '@salesforce/resourceUrl/default_thumbnail';

// Apex
import getFieldSetFields from '@salesforce/apex/ListingFilterMobileCtrl.getFieldSetFields';
import getListingSetFields from '@salesforce/apex/ListingFilterMobileCtrl.getListingSetFields';
import getListings from '@salesforce/apex/ListingFilterMobileCtrl.getListings';
import lookupOptions from '@salesforce/apex/ListingFilterMobileCtrl.lookupOptions';
import getDistinctFieldValues from '@salesforce/apex/ListingFilterMobileCtrl.getDistinctFieldValues';
import getDistinctSubCommunitiesForCommunities
  from '@salesforce/apex/ListingFilterMobileCtrl.getDistinctSubCommunitiesForCommunities';

// ===== Constants =====
const MOBILE_PAGE = 20;
const TABLET_PAGE = 30;
const LOOKUP_DEBOUNCE_MS = 300;
const MULTI_TEXT_LIMIT = 500;

// API names for the searchable multi-selects
const FIELD_COMMUNITY = 'Community_Propertyfinder__c';
const FIELD_SUBCOMM  = 'Sub_Community_Propertyfinder__c';

// Hide from KV because rendered as TAGS
const HIDE_IF_TAG = new Set([
  'Mandate__c', 'Mandate',
  'Status__c', 'Status',
  'Property_Sub_Type__c', 'Property_Sub_Type',
  'os_ListingPrice_pb__c', 'Price__c', 'Price'
]);

// Hide from KV because rendered as FACTS
const HIDE_IF_FACT = new Set([
  'Bedrooms__c', 'Bedrooms',
  'Bathrooms__c', 'Bathrooms',
  'Built_Up_Area_sqft__c', 'BUA_sqft__c', 'Area_sqft__c',
  'City__c', 'City',
  'Address__c', 'Address',
  FIELD_COMMUNITY, FIELD_SUBCOMM
]);

export default class ListingFilterMobile extends NavigationMixin(LightningElement) {
  /* ===== Data/state ===== */
  @track fields = [];
  @track displayFields = [];
  @track rows = [];
  @track total = 0;

  /* ===== UI state ===== */
  @track loading = true;      // initial skeletons
  @track showFilters = false; // filters open on big-search click
  @track searched = false;

  // hero background
  heroUrl = '';
  get heroStyle() { return this.heroUrl ? `background-image:url('${this.heroUrl}')` : ''; }
  get skeletons() { return Array.from({ length: 20 }, (_, i) => i); }

  // Sorting (hint to server)
  sortBy = 'LastModifiedDate_DESC';
  get sortOptions() {
    return [
      { label: 'Newest', value: 'LastModifiedDate_DESC' },
      { label: 'Price: High → Low', value: 'os_ListingPrice_pb__c_DESC' },
      { label: 'Price: Low → High', value: 'os_ListingPrice_pb__c_ASC' },
      { label: 'Bedrooms', value: 'Bedrooms__c_DESC' }
    ];
  }

  // Paging
  page = 0;
  pageSize = MOBILE_PAGE;

  // Debouncers
  _lookupTimers = {};
  _multiTextTimers = {};

  /* ===== Lifecycle ===== */
  connectedCallback() {
    this.pageSize = this._calcPageSize();
    window.addEventListener('resize', this._onResize);

    // Close any lookup/multitext dropdown when clicking outside
    this._onDocClick = (evt) => {
      const inLookup = this.template.contains(evt.target) && evt.target.closest?.('.lookup');
      if (!inLookup) {
        this.fields = this.fields.map(f =>
          (f.isReference || f.isMultiText) ? { ...f, showDropdown: false } : f
        );
      }
    };
    document.addEventListener('click', this._onDocClick, true);

    // Fonts
    loadStyle(this, `${benton}/fonts.css`).catch(() => {});
    loadStyle(this, `${freight}/fonts.css`).catch(() => {});

    // Describe field sets
    Promise.all([getFieldSetFields(), getListingSetFields()])
      .then(([filterList, displayList]) => {
        // Map Filter_Listing fields to renderer
        this.fields = (filterList || []).map(f => {
          const dt = (f.dataType || '').toLowerCase();
          const isBoolean = dt === 'boolean';
          const isDate = dt === 'date';
          const isDatetime = dt === 'datetime';
          const isNumeric = ['currency', 'double', 'integer', 'long', 'percent'].includes(dt);
          const isPicklist = dt === 'picklist';
          const isMultiPicklist = dt === 'multipicklist';
          const isReference = dt === 'reference';
          const isTextLike = !(isBoolean || isDate || isDatetime || isNumeric || isPicklist || isMultiPicklist || isReference);
          const opts = (f.picklistOptions || []).map(o => ({ label: o.label, value: o.value }));

          return {
            ...f,
            value: isMultiPicklist ? [] : '',
            isBoolean, isDate, isDatetime, isNumeric, isPicklist, isMultiPicklist, isReference, isTextLike,
            isMultiText: false,
            picklistOptions: isPicklist ? [{ label: '--None--', value: '' }, ...opts] : (isMultiPicklist ? opts : []),
            ...(isReference ? { options: [], searchTerm: '', showDropdown: false, showNoResults: false } : {})
          };
        });

        // Ensure our searchable multi-selects are present & rendered as token fields
        this._ensureMultiText(FIELD_COMMUNITY, 'Community');
        this._ensureMultiText(FIELD_SUBCOMM, 'Sub Community');

        this.displayFields = displayList || [];
      })
      .catch(err => {
        // eslint-disable-next-line no-console
        console.error('Describe error (fallback to multi-text filters):', err);
        this.fields = [];
        this._ensureMultiText(FIELD_COMMUNITY, 'Community');
        this._ensureMultiText(FIELD_SUBCOMM, 'Sub Community');
        this.displayFields = [];
      })
      .finally(() => { this.loading = false; });

    // Hero image
    this.heroUrl = listingPanel;
  }

  disconnectedCallback() {
    window.removeEventListener('resize', this._onResize);
    document.removeEventListener('click', this._onDocClick, true);
  }

  /* ===== Getters ===== */
  get booleanOptions() {
    return [
      { label: '--None--', value: '' },
      { label: 'True', value: 'true' },
      { label: 'False', value: 'false' }
    ];
  }
  get filtersClass() { return this.showFilters ? 'filters reveal' : 'filters'; }
  get isFirst() { return this.page === 0; }
  get isLast() { return (this.page + 1) * this.pageSize >= this.total; }
  get pageFrom() { return this.total === 0 ? 0 : (this.page * this.pageSize) + 1; }
  get pageTo() { return Math.min((this.page + 1) * this.pageSize, this.total); }
  get noData() { return !this.loading && this.rows.length === 0 && this.searched; }

  // Safer booleans for template conditions
  get hasFields() { return Array.isArray(this.fields) && this.fields.length > 0; }
  get hasRows() { return Array.isArray(this.rows) && this.rows.length > 0; }
  get hasAppliedFilters() { return this.appliedFilters.length > 0; }

  // Applied-filter chips
  get appliedFilters() {
    const chips = [];
    for (const f of this.fields) {
      if (f.isMultiPicklist && Array.isArray(f.value) && f.value.length) {
        chips.push({ apiName: f.apiName, label: f.label, display: f.value.join(', ') });
      } else if (f.isReference) {
        if (f.searchTerm && f.value) chips.push({ apiName: f.apiName, label: f.label, display: f.searchTerm });
      } else if (f.isMultiText) {
        if (Array.isArray(f.value) && f.value.length) chips.push({ apiName: f.apiName, label: f.label, display: f.value.join(', ') });
      } else {
        const v = (f.value ?? '').toString().trim();
        if (v) chips.push({ apiName: f.apiName, label: f.label, display: v });
      }
    }
    return chips;
  }

  /* ===== UI Events ===== */
  openFilters = () => { this.showFilters = true; };
  cancelFilters = () => { this.showFilters = false; };

  onKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      this.page = 0;
      this.search();
    }
  };

  // Standard inputs
  onFieldInput(e) {
    const a = e.target.name, v = e.detail?.value ?? e.target?.value ?? '';
    this.fields = this.fields.map(f => f.apiName === a ? { ...f, value: v } : f);
  }
  onFieldChange(e) {
    const a = e.target.name, v = e.detail?.value ?? e.target?.value ?? '';
    this.fields = this.fields.map(f => f.apiName === a ? { ...f, value: v } : f);
  }
  onMultiChange(e) {
    const a = e.target.name, arr = e.detail?.value || [];
    this.fields = this.fields.map(f => f.apiName === a ? { ...f, value: arr } : f);
  }
  onSortChange = (e) => { this.sortBy = e.detail.value; };

  removeChip = (e) => {
    const api = e.currentTarget.dataset.api;
    this.fields = this.fields.map(f => {
      if (f.apiName !== api) return f;
      if (f.isMultiPicklist) return { ...f, value: [] };
      if (f.isReference) return { ...f, value: '', searchTerm: '', options: [], showDropdown: false, showNoResults: false };
      if (f.isMultiText) return { ...f, value: [], options: (f.options || []).map(o => ({ ...o, selected: false })) };
      return { ...f, value: '' };
    });
    if (api === FIELD_COMMUNITY) {
      // When community chips change, clear & repopulate Sub Community list
      this._patchField(FIELD_SUBCOMM, {
        value: [],
        options: (this.fields.find(x => x.apiName === FIELD_SUBCOMM)?.options || []).map(o => ({ ...o, selected: false })),
        showDropdown: false,
        showNoResults: false,
        searchTerm: ''
      });
    }
  };

  /* ===== Reference Lookup ===== */
  onRefInput = (e) => {
    const api = e.target.name;
    const term = e.detail?.value ?? e.target?.value ?? '';
    this._patchField(api, { searchTerm: term });

    if (!term.trim()) {
      this._patchField(api, { options: [], showDropdown: false, showNoResults: false, value: '' });
      return;
    }

    window.clearTimeout(this._lookupTimers[api]);
    this._lookupTimers[api] = window.setTimeout(() => {
      this._fetchLookup(api, term);
    }, LOOKUP_DEBOUNCE_MS);
  };

  async _fetchLookup(api, term) {
    try {
      const opts = await lookupOptions({ fieldApi: api, searchTerm: term, limitSize: 25 });
      const has = Array.isArray(opts) && opts.length > 0;
      this._patchField(api, {
        options: opts || [],
        showDropdown: true,
        showNoResults: !has
      });
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error('Lookup fetch error', err);
      this._patchField(api, { options: [], showDropdown: true, showNoResults: true });
    }
  }

  onRefPick = (e) => {
    const api = e.currentTarget.dataset.api;
    const val = e.currentTarget.dataset.value; // Id
    const label = e.currentTarget.dataset.label;

    this._patchField(api, {
      value: val,
      searchTerm: label,
      options: [],
      showDropdown: false,
      showNoResults: false
    });
  };

  /* ===== Searchable Multi-Select (Community & Sub Community) ===== */
  onMultiTextFocus = (e) => {
    const api = e.currentTarget.dataset.api;
    const term = this.fields.find(f => f.apiName === api)?.searchTerm || '';
    if (api === FIELD_SUBCOMM) this._refreshSubCommunities(term);
    else this._fetchDistinct(api, term);
  };

  onMultiTextInput = (e) => {
    const api = e.currentTarget.dataset.api;
    const term = e.detail?.value ?? e.target?.value ?? '';
    this._patchField(api, { searchTerm: term });

    window.clearTimeout(this._multiTextTimers[api]);
    this._multiTextTimers[api] = window.setTimeout(() => {
      if (api === FIELD_SUBCOMM) this._refreshSubCommunities(term);
      else this._fetchDistinct(api, term);
    }, 180);
  };

  async _fetchDistinct(api, term) {
    try {
      const vals = await getDistinctFieldValues({ fieldApi: api, searchTerm: term, limitSize: MULTI_TEXT_LIMIT });
      const uniq = Array.from(new Set((vals || []).map(v => (v || '').trim()).filter(v => v)));
      const current = (this.fields.find(f => f.apiName === api)?.value) || [];
      const selectedSet = new Set(current);
      const optObjs = uniq.map(v => ({ label: v, value: v, selected: selectedSet.has(v) }));

      this._patchField(api, {
        options: optObjs,
        showDropdown: true,
        showNoResults: optObjs.length === 0
      });
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error('distinct error', e);
      this._patchField(api, { options: [], showDropdown: true, showNoResults: true });
    }
  }

  get _selectedCommunities() {
    const f = this.fields.find(x => x.apiName === FIELD_COMMUNITY);
    return Array.isArray(f?.value) ? f.value : [];
  }

  async _refreshSubCommunities(searchTerm = '') {
    const comms = this._selectedCommunities;
    try {
      let vals;
      if (comms.length) {
        // Scoped by selected communities
        vals = await getDistinctSubCommunitiesForCommunities({
          communities: comms,
          searchTerm,
          limitSize: MULTI_TEXT_LIMIT
        });
      } else {
        // No community chosen yet → show global sub communities (with search)
        vals = await getDistinctFieldValues({
          fieldApi: FIELD_SUBCOMM,
          searchTerm,
          limitSize: MULTI_TEXT_LIMIT
        });
      }

      const uniq = Array.from(new Set((vals || []).map(v => (v || '').trim()).filter(v => v)));
      const current = (this.fields.find(f => f.apiName === FIELD_SUBCOMM)?.value) || [];
      const selectedSet = new Set(current);
      const optObjs = uniq.map(v => ({ label: v, value: v, selected: selectedSet.has(v) }));

      this._patchField(FIELD_SUBCOMM, {
        options: optObjs,
        showDropdown: true,
        showNoResults: optObjs.length === 0
      });
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error('scoped sub-communities error', e);
      this._patchField(FIELD_SUBCOMM, { options: [], showDropdown: true, showNoResults: true });
    }
  }

  // Toggle token on click; scope Sub Community when Community changes
  onMultiTextPick = (e) => {
    const api = e.currentTarget.dataset.api;
    const val = e.currentTarget.dataset.value;

    const f = this.fields.find(x => x.apiName === api);
    const has = (f?.value || []).includes(val);
    const nextValues = has ? (f.value || []).filter(v => v !== val) : [...(f.value || []), val];

    const selectedSet = new Set(nextValues);
    const nextOptions = (f.options || []).map(o => ({ ...o, selected: selectedSet.has(o.value) }));

    // Update + keep dropdown open for multi picks
    this._patchField(api, { value: nextValues, options: nextOptions, showDropdown: true, searchTerm: '' });

    if (api === FIELD_COMMUNITY) {
      // Reset sub communities & repopulate scoped options
      this._patchField(FIELD_SUBCOMM, {
        value: [],
        options: (this.fields.find(x => x.apiName === FIELD_SUBCOMM)?.options || []).map(o => ({ ...o, selected: false })),
        showDropdown: true,
        showNoResults: false,
        searchTerm: ''
      });
      this._refreshSubCommunities('');
    }
  };

  /* ===== Search & Pagination ===== */
  search() {
    this.searched = true;
    this.loading = true;

    const payload = this._buildFiltersPayload();
    payload._sort = { value: this.sortBy }; // server may ignore; hint only

    const offset = this.page * this.pageSize;

    getListings({ filters: payload, pageSize: this.pageSize, offsetRows: offset })
      .then(res => {
        const media = res?.media || {};
        const mediaList = res?.mediaList || {};
        const rows = res?.rows || [];

        this.rows = rows.map(r => {
          // images
          const imgs = mediaList[r.Id] || [];
          const primary = media[r.Id] || defaultThumbnail;
          const allImgs = imgs.length ? imgs : [primary];

          const base = {
            ...r,
            _imgs: allImgs,
            _img: primary,
            _hasMulti: allImgs.length > 1,
            _statusClass: this.computeStatusClass(r.Status__c || r.Status)
          };

          // enrich
          const tags  = this._buildTags(r);
          const facts = this._buildFacts(r);

          // KV excluding tags/facts fields
          const kv = (this.displayFields || [])
            .filter(df => !HIDE_IF_TAG.has(df.apiName) && !HIDE_IF_FACT.has(df.apiName))
            .map(df => {
              const raw = this._getByPath(r, df.readPath);
              const formatted = this._formatDisplay(df, raw);
              return (formatted === null || formatted === undefined || formatted === '')
                ? null
                : { key: df.apiName, label: df.label, value: formatted };
            })
            .filter(Boolean);

          // map
          const query = this._buildMapQuery(r);
          const mapsUrl = this._buildMapsUrl(r, query);

          return { ...base, _kv: kv, _mapsQuery: query, _mapsUrl: mapsUrl, _tags: tags, _facts: facts };
        });

        this.total = res?.total || 0;
        if (this.showFilters) this.showFilters = false;
        this._scrollTop();
      })
      .catch(err => {
        // eslint-disable-next-line no-console
        console.error('Query error', err);
        this.rows = [];
        this.total = 0;
      })
      .finally(() => { this.loading = false; });
  }

  _buildFiltersPayload() {
    const payload = {};
    for (const f of this.fields) {
      // Searchable multi-text -> IN(...)
      if (f.isMultiText) {
        if (Array.isArray(f.value) && f.value.length) {
          payload[f.apiName] = { value: f.value.join('|'), mode: 'in' };
        }
        continue;
      }
      // Native multi-picklist
      if (f.isMultiPicklist) {
        if (Array.isArray(f.value) && f.value.length) payload[f.apiName] = { value: f.value.join(';') };
        continue;
      }
      // Reference
      if (f.isReference) {
        const idOrLabel = (f.value || f.searchTerm || '').toString().trim();
        if (idOrLabel) payload[f.apiName] = { value: idOrLabel };
        continue;
      }
      // Others
      const s = (f.value ?? '').toString().trim();
      if (!s) continue;
      payload[f.apiName] = { value: s };
    }
    return payload;
  }

  clearAll() {
    Object.keys(this._lookupTimers).forEach(k => window.clearTimeout(this._lookupTimers[k]));
    Object.keys(this._multiTextTimers).forEach(k => window.clearTimeout(this._multiTextTimers[k]));
    this.fields = this.fields.map(f => ({
      ...f,
      value: (f.isMultiPicklist || f.isMultiText) ? [] : '',
      ...(f.isReference ? { options: [], searchTerm: '', showDropdown: false, showNoResults: false } : {}),
      ...(f.isMultiText ? { options: (f.options || []).map(o => ({ ...o, selected: false })), searchTerm: '', showDropdown: false, showNoResults: false } : {})
    }));
    this.page = 0;
  }

  next() { if (!this.isLast) { this.page += 1; this.search(); } }
  prev() { if (!this.isFirst) { this.page -= 1; this.search(); } }

  /* ===== Navigation / Images / Maps ===== */
  openRecord(e) {
    const recId = e.currentTarget.dataset.id;
    this[NavigationMixin.Navigate]({
      type: 'standard__recordPage',
      attributes: { recordId: recId, objectApiName: 'Listing__c', actionName: 'view' }
    });
  }

  fallbackThumb(e) {
    try {
      const img = e?.target;
      if (!img) return;
      if (img.dataset.fb === '1') return;
      img.dataset.fb = '1';
      img.src = defaultThumbnail;
    } catch {}
  }

  onSlidesKeydown = (e) => {
    const cont = e.currentTarget;
    if (!cont) return;
    if (e.key === 'ArrowRight') { e.preventDefault(); this._scrollOne(cont, +1); }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); this._scrollOne(cont, -1); }
  };
  nextSlide = (e) => {
    e.preventDefault(); e.stopPropagation();
    const cont = e.currentTarget?.closest('.thumb')?.querySelector('.slides');
    if (cont) this._scrollOne(cont, +1);
  };
  prevSlide = (e) => {
    e.preventDefault(); e.stopPropagation();
    const cont = e.currentTarget?.closest('.thumb')?.querySelector('.slides');
    if (cont) this._scrollOne(cont, -1);
  };
  _scrollOne(cont, dir = +1) {
    try { cont.scrollBy({ left: dir * (cont.clientWidth || 0), behavior: 'smooth' }); } catch {}
  }

  openMap(e) {
    e.preventDefault(); e.stopPropagation();
    const url = e.currentTarget.dataset.url;
    const q   = e.currentTarget.dataset.q;
    const finalUrl = url || (q ? this._mapsLinkForQuery(q) : null);
    if (!finalUrl) return;
    try {
      this[NavigationMixin.Navigate]({ type: 'standard__webPage', attributes: { url: finalUrl } });
    } catch {
      window.open(finalUrl, '_blank', 'noopener');
    }
  }

  _buildMapsUrl(rec, query) {
    const lat = Number(rec.Latitude__c);
    const lng = Number(rec.Longitude__c);
    if (Number.isFinite(lat) && Number.isFinite(lng)) return this._mapsLinkForQuery(`${lat},${lng}`);
    return this._mapsLinkForQuery(query);
  }
  _mapsLinkForQuery(q) {
    if (!q) return null;
    const ua = (navigator?.userAgent || '').toLowerCase();
    const isIOS = /iphone|ipad|ipod/.test(ua);
    return isIOS ? `maps://?q=${encodeURIComponent(q)}` :
                   `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(q)}`;
  }
  _buildMapQuery(rec) {
    const parts = [];
    const add = (v) => { if (v && String(v).trim()) parts.push(String(v).trim()); };
    add(rec.Address__c || rec.Address); // hidden from KV, still used in query
    add(rec[FIELD_SUBCOMM]);
    add(rec[FIELD_COMMUNITY]);
    add(rec.City__c || rec.City);
    add(rec.Listing_Region__c || rec.Region__c || rec.State__c);
    add(rec.Country__c);
    if (!parts.length && rec.Name) add(rec.Name);
    return parts.join(', ');
  }

  /* ===== Helpers ===== */
  _calcPageSize() {
    try { return (window.innerWidth || 0) >= 768 ? TABLET_PAGE : MOBILE_PAGE; }
    catch { return MOBILE_PAGE; }
  }
  _onResize = () => {
    const newSize = this._calcPageSize();
    if (newSize !== this.pageSize) {
      this.pageSize = newSize;
      this.page = 0;
      if (this.searched) this.search();
    }
  };
  _scrollTop() {
    try { this.template.querySelector('.outer')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch {}
  }

  computeStatusClass(status) {
    const base = 'badge pill';
    if (!status) return base;
    const s = String(status).toLowerCase();
    if (s.includes('available')) return `${base} success`;
    if (s.includes('sold') || s.includes('reserved')) return `${base} danger`;
    if (s.includes('pending') || s.includes('offer')) return `${base} warn`;
    return base;
  }

  formatPriceNumber(v) {
    const n = Number(v);
    if (!isFinite(n)) return v;
    if (n >= 1_000_000) return `AED ${(n/1_000_000).toFixed(1)}M`;
    if (n >= 1_000)     return `AED ${(n/1_000).toFixed(0)}K`;
    return `AED ${n.toLocaleString()}`;
  }

  _getByPath(obj, path) {
    if (!obj || !path) return null;
    return path.split('.').reduce((o, k) => (o && o[k] !== undefined && o[k] !== null ? o[k] : null), obj);
  }

  _formatDisplay(df, val) {
    if (val === null || val === undefined) return null;
    if (typeof val === 'string') {
      const t = val.trim();
      if (!t) return null;
    }
    const api = df.apiName;
    if (api === 'CreatedDate' || /created\s*date/i.test(df.label)) {
      try { return new Date(val).toLocaleDateString(); } catch { return null; }
    }
    if (api === 'os_ListingPrice_pb__c' || api === 'Price__c' || /price/i.test(df.label)) {
      const n = Number(val);
      if (!isNaN(n)) return this.formatPriceNumber(n);
      return String(val).trim();
    }
    return String(val).trim();
  }

  _patchField(api, patch) {
    this.fields = this.fields.map(f => (f.apiName === api ? { ...f, ...patch } : f));
  }

  _ensureMultiText(api, label) {
    const exists = this.fields.some(f => f.apiName === api);
    if (!exists) {
      this.fields.push({
        apiName: api,
        label,
        dataType: 'String',
        isBoolean: false, isDate: false, isDatetime: false, isNumeric: false,
        isPicklist: false, isMultiPicklist: false, isReference: false, isTextLike: false,
        isMultiText: true,
        value: [],
        options: [], // [{label, value, selected}]
        searchTerm: '',
        showDropdown: false,
        showNoResults: false
      });
    } else {
      // Convert existing to our searchable token renderer
      this.fields = this.fields.map(f => f.apiName === api ? {
        ...f,
        isBoolean: false, isDate: false, isDatetime: false, isNumeric: false,
        isPicklist: false, isMultiPicklist: false, isReference: false, isTextLike: false,
        isMultiText: true,
        value: Array.isArray(f.value) ? f.value : [],
        options: [],
        searchTerm: '',
        showDropdown: false,
        showNoResults: false
      } : f);
    }
  }

  _buildTags(r) {
    const out = [];
    const add = (label, tone, key) => {
      if (!label) return;
      const text = String(label).trim();
      if (!text) return;
      out.push({ key: key || `${tone}-${text}`, label: text, className: `tag ${tone}` });
    };

    add(r.Mandate__c || r.Mandate, 'info', 'mandate');

    const s = (r.Status__c || r.Status || '').toLowerCase();
    if (s.includes('available')) add(r.Status__c || r.Status, 'success', 'status');
    else if (s.includes('sold') || s.includes('reserved')) add(r.Status__c || r.Status, 'danger', 'status');
    else if (s.includes('pending') || s.includes('offer')) add(r.Status__c || r.Status, 'warn', 'status');
    else if (r.Status__c || r.Status) add(r.Status__c || r.Status, 'muted', 'status');

    add(r.Property_Sub_Type__c || r.Property_Sub_Type, 'muted', 'ptype');

    const rawPrice = r.os_ListingPrice_pb__c ?? r.Price__c ?? r.Price;
    if (rawPrice !== undefined && rawPrice !== null && String(rawPrice).trim() !== '') {
      const n = Number(rawPrice);
      const label = Number.isFinite(n) ? this.formatPriceNumber(n) : String(rawPrice);
      add(label, 'brand', 'price');
    }

    try {
      const created = new Date(r.CreatedDate || r.Created_Date__c || r.Created_On__c);
      if (!isNaN(created.getTime())) {
        const days = (Date.now() - created.getTime()) / (1000*60*60*24);
        if (days <= 14) add('New', 'brand', 'new');
      }
    } catch {}

    return out;
  }

  _buildFacts(r) {
    const out = [];
    const add = (key, emoji, text) => {
      if (text === null || text === undefined) return;
      const t = String(text).trim();
      if (!t) return;
      out.push({ key, emoji, text: t });
    };

    if (Number.isFinite(Number(r.Bedrooms__c))) add('beds', '🛏', Number(r.Bedrooms__c));
    if (Number.isFinite(Number(r.Bathrooms__c))) add('baths', '🛁', Number(r.Bathrooms__c));

    const sqft = Number(r.Built_Up_Area_sqft__c || r.BUA_sqft__c || r.Area_sqft__c);
    if (Number.isFinite(sqft) && sqft > 0) add('area', '📐', `${Math.round(sqft).toLocaleString()} sqft`);

    const city = r.City__c || r.City;
    const subc = r[FIELD_SUBCOMM];
    const comm = r[FIELD_COMMUNITY];
    const addr = r.Address__c || r.Address;
    const loc  = [addr, subc, comm, city].filter(Boolean).join(', ');
    add('loc', '📍', loc);

    return out;
  }
}