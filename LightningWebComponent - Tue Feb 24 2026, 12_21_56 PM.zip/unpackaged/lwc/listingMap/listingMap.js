import { LightningElement, api, wire } from 'lwc';
import getListingAddress from '@salesforce/apex/ListingMapController.getListingAddress';

export default class ListingMap extends LightningElement {
    @api recordId;

    mapUrl;
    error;

    @wire(getListingAddress, { listingId: '$recordId' })
    wiredData({ error, data }) {
        if (data) {
            const {
                street,
                city,
                state,
                postalCode,
                country,
                latitude,
                longitude,
                apiKey
            } = data;

            if (latitude && longitude) {
                // Use lat/lng for exact pointer
                this.mapUrl = `https://www.google.com/maps/embed/v1/place?key=${apiKey}&q=${latitude},${longitude}`;
            } else {
                // Fallback to address string
                const address = `${street}, ${city}, ${state}, ${postalCode}, ${country}`;
                const encodedAddress = encodeURIComponent(address);
                this.mapUrl = `https://www.google.com/maps/embed/v1/place?key=${apiKey}&q=${encodedAddress}`;
            }

            this.error = undefined;
        } else if (error) {
            this.error = 'Failed to load map.';
            this.mapUrl = undefined;
            console.error(error);
        }
    }
}