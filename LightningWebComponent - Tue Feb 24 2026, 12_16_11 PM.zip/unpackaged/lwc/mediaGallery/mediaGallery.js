import { LightningElement, api, track, wire } from 'lwc';
import uploadFile from '@salesforce/apex/FileUploadControllerInGallery.uploadFile';
import getUploadedImages from '@salesforce/apex/FileUploadControllerInGallery.getUploadedImages';
import updateImageOrder from '@salesforce/apex/FileUploadControllerInGallery.updateImageOrder';
import deleteMediaRecord from '@salesforce/apex/FileUploadControllerInGallery.deleteMediaRecord';
import updateTagForMedia from '@salesforce/apex/FileUploadControllerInGallery.updateTagForMedia';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import TAG_FIELD from '@salesforce/schema/Property_Media__c.Tag__c';
import MEDIA_OBJECT from '@salesforce/schema/Property_Media__c';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import uploadToS3FromContentVersion from '@salesforce/apex/FileUploadToS3Controller.uploadToS3FromContentVersion';
import getJobStatus from '@salesforce/apex/FileUploadToS3Controller.getJobStatus';

export default class ImageUpload extends LightningElement {
    @api recordId;
    @track images = [];
    draggedIndex = null;
    @track tagOptions = [];
    @track isUploading = false;
    @track uploadIndex = 0;
    @track uploadTotal = 0;
    @track isModalOpen = false;

    connectedCallback() {
        this.fetchImages();
    }

    // handleOpenModal() {
    //     this.isModalOpen = true;
    // }

    // handleCloseModal() {
    //     this.isModalOpen = false;
    // }

    showToast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }

    /*async handleFileChange(event) {
        const files = Array.from(event.target.files);
        this.isUploading = true;
        this.uploadTotal = files.length;

        const MAX_SIZE_MB = 5; // max size for base64 upload through Apex
        const MAX_SIZE_BYTES = MAX_SIZE_MB * 1024 * 1024;

        for (let i = 0; i < files.length; i++) {
            const file = files[i];

            if (file.size > MAX_SIZE_BYTES) {
                this.showToast('Error', `${file.name} exceeds ${MAX_SIZE_MB} MB limit for upload.`, 'error');
                continue;
            }

            try {
                // Convert file to base64 string
                const base64Data = await this.readFileAsBase64(file);

                // Strip out the metadata prefix: "data:<type>;base64," if present
                const base64String = base64Data.split(',')[1];

                // Call Apex uploadFile
                await uploadFile({
                    fileName: file.name,
                    blobData: base64String,
                    recordId: this.recordId
                });

                this.showToast('Success', `${file.name} uploaded successfully.`, 'success');

            } catch (error) {
                console.error('Upload Error:', error);
                this.showToast('Error', `Failed to upload ${file.name}`, 'error');
            }
        }

        this.isUploading = false;
        this.fetchImages();
    }

    // Helper to read file as base64 string
    readFileAsBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = error => reject(error);
            reader.readAsDataURL(file);
        });
    }*/

    // Upload File
    handleUploadFinished(event) {
        const uploadedFiles = event.detail.files;
        console.log('uploadedFiles', uploadedFiles);
        this.isUploading = true;
        for (let file of uploadedFiles) {
            console.log('Uploaded file ID:', file.documentId);
            this.sendFileToS3(file.documentId);
        }
    }

    async sendFileToS3(contentVersionId) {
        try {
            await uploadToS3FromContentVersion({
                recordId: this.recordId,
                contentDocId: contentVersionId,
            }).then(result => {
                console.log('resultEr', result.bError);
                console.log('resultFN', result.fileName);
                console.log('resultJI', result.jobId);
                if(result.bError){
                    let msg = result.fileName + ' exceeds 10 MB limit for upload.';
                    this.showToast('Error', msg, 'error');
                }
                else {
                    this.jobId = result.jobId;
                    let msg = result.fileName + ' uploaded successfully.';
                    this.showToast('Success', msg, 'success');
                }
            })
            .catch(error => {
                console.error('Upload failed:', error);
                this.showToast('Error', `Failed to upload`, 'error');
            });
            console.log('File sent to S3');
            setTimeout(() => {
                this.startPolling();
            }, 5000);
            
        } catch (err) {
            console.error('Failed to send to S3', err);
            this.showToast('Error', `Failed to upload`, 'error');
        }
    }

    startPolling() {
        // Start polling every 5 seconds
        this.intervalId = setInterval(() => {
            this.checkStatus();
        }, 5000); 
    }

    checkStatus() {
        getJobStatus({ sJobId: this.jobId })
            .then((status) => {
                console.log('status'+status);
                if(status === 'Completed'){
                   clearInterval(this.intervalId);
                   this.fetchImages();
                   this.isUploading = false;
                }
            })
            .catch((error) => {
                console.error('Error checking job status:', error);
                clearInterval(this.intervalId);
            });
    }

    disconnectedCallback() {
        // Clean up polling
        if (this.intervalId) {
            clearInterval(this.intervalId);
        }
    }

    connectedCallback() {
        this.fetchImages();
    }
    handleOpenModal() {
        this.isModalOpen = true;
    }

    handleCloseModal() {
        this.isModalOpen = false;
    }
    handleSuccess(event) {
        this.showToast('Success', 'Property Media record created successfully.', 'success');
        this.isModalOpen = false;

        // Refresh the media list
        this.fetchImages();
    }

    fetchImages() {
        getUploadedImages({ recordId: this.recordId })
            .then(result => {
                this.images = result.map((file, index) => {
                    const tagClass = this.getTagClass(file.Tag__c);
                    const url = file.Public_URL__c;

                    const image = {
                        id: file.Id,
                        url: file.Public_URL__c,
                        serialNumber: index + 1,
                       name: file.Name || 'Unnamed',
                        tag: file.Tag__c || 'No Tag',
                        tagClass: tagClass,
                        isYouTube: false,
                        isVideo: false,
                        embedUrl: '',
                        thumbnailUrl: ''
                    };

                    const youtubeMatch = file.Public_URL__c?.match(
                        /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/
                    );

                    if (youtubeMatch && youtubeMatch[1]) {
                        const videoId = youtubeMatch[1];
                        image.isYouTube = true;
                        image.thumbnailUrl = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
                        image.embedUrl = `https://www.youtube.com/embed/${videoId}`;
                    } else if (url?.endsWith('.mp4')) {
                        image.isVideo = true;
                    }

                    return image;
                });
            })
            .catch(error => {
                console.error('Error fetching images', error);
            });
    }

    handleDragStart(event) {
        this.draggedIndex = Number(event.currentTarget.dataset.index);
        event.dataTransfer.effectAllowed = 'move';
    }

    handleDrop(event) {
        event.preventDefault();
        const droppedIndex = Number(event.currentTarget.dataset.index);

        if (this.draggedIndex !== null && this.draggedIndex !== droppedIndex) {
            const updatedImages = [...this.images];
            const temp = updatedImages[this.draggedIndex];
            updatedImages[this.draggedIndex] = updatedImages[droppedIndex];
            updatedImages[droppedIndex] = temp;

            updatedImages.forEach((img, index) => {
                img.serialNumber = index + 1;
            });

            this.images = [...updatedImages];

            updateImageOrder({ mediaList: updatedImages })
                .then(() => this.showToast('Success', 'Order updated.', 'success'))
                .catch(error => {
                    this.showToast('Error', 'Failed to update order', 'error');
                });
        }

        this.draggedIndex = null;
    }

    allowDrop(event) {
        event.preventDefault();
    }

    getTagClass(tag) {
        switch (tag) {
            case 'EPC': return 'tag-epc';
            case 'Important': return 'tag-important';
            default: return 'tag-default';
        }
    }

    @wire(getObjectInfo, { objectApiName: MEDIA_OBJECT }) objectInfo;

    @wire(getPicklistValues, {
        recordTypeId: '$objectInfo.data.defaultRecordTypeId',
        fieldApiName: TAG_FIELD
    })
    wiredPicklistValues({ error, data }) {
        if (data) {
            this.tagOptions = data.values.map(item => ({
                label: item.label,
                value: item.value
            }));
        } else if (error) {
            console.error('Picklist error:', error);
        }
    }

    handleEvent(event) {
        const selectedTag = event.detail.value;
        const index = event.target.dataset.index;
        const image = this.images[index];

        updateTagForMedia({ mediaId: image.id, newTag: selectedTag })
            .then(() => {
                this.images[index].tag = selectedTag;
                this.images = [...this.images];
                this.showToast('Success', 'Tag updated.', 'success');
            })
            .catch(error => {
                this.showToast('Error', 'Tag update failed.', 'error');
            });
    }

    handleDelete(event) {
        const index = event.currentTarget.dataset.index;
        const recordId = this.images[index].id;

        deleteMediaRecord({ mediaId: recordId })
            .then(() => {
                this.images = this.images.filter((_, i) => i !== index);
                this.showToast('Success', 'Image deleted.', 'success');
            })
            .catch(error => {
                this.showToast('Error', 'Delete failed.', 'error');
            });
    }
}