import { LightningElement, api, wire, track } from 'lwc';
import getAgentListingData from '@salesforce/apex/AgentDirectoryController.getAgentListingData';
import getAllMediaForListing from '@salesforce/apex/AgentDirectoryController.getAllMediaForListing';

export default class AgentDetailView extends LightningElement {
    @api agentId;

    @track agent = {};
    @track listings = [];
    @track selectedType = 'Sale';
    @track isLoading = true;

    @track totalPropertyValue = 0;
    @track activeListingsCount = 0;
    @track closedDealsCount = 0;
    @track totalClosedAmount = 0;

    get formattedTotalPropertyValue() {
        return '$' + (this.totalPropertyValue || 0).toLocaleString();
    }

    get formattedTotalClosedAmount() {
        return '$' + (this.totalClosedAmount || 0).toLocaleString();
    }

    get filteredListings() {
        if (!this.listings) return [];
        return this.listings.filter(item => {
            if (!item.Listing_Type__c) return false;
            return item.Listing_Type__c
                .toLowerCase()
                .includes(this.selectedType.toLowerCase());
        });
    }

    get saleTabClass() {
        return this.selectedType === 'Sale' ? 'active-tab' : 'inactive-tab';
    }

    get rentTabClass() {
        return this.selectedType === 'Rent'
            ? 'active-tab slds-m-left_medium'
            : 'inactive-tab slds-m-left_medium';
    }

    @wire(getAgentListingData, { agentId: '$agentId' })
    async wiredData({ error, data }) {
        if (data) {
            this.agent = data.agent[0] || {};
            const rawListings = data.listings || [];

            // Fetch images for all listings simultaneously
            try {
                this.listings = await Promise.all(rawListings.map(async (item) => {
                    const createdDate = new Date(item.CreatedDate);
                    const today = new Date();
                    const diffDays = Math.floor((today - createdDate) / (1000 * 60 * 60 * 24));

                    // Call the media method for each specific listing ID
                    const mediaRecords = await getAllMediaForListing({ listingId: item.Id });
                    
                    // Logic: Use the first image found, otherwise use a placeholder
                    const thumbnailUrl = (mediaRecords && mediaRecords.length > 0) 
                        ? mediaRecords[0].Public_URL__c 
                        : 'https://via.placeholder.com/150';

                    return {
                        ...item,
                        daysAgo: diffDays,
                        thumbnail: thumbnailUrl, // This is the property you'll use in HTML
                        formattedPrice: item.os_ListingPrice_pb__c
                            ? '$' + item.os_ListingPrice_pb__c.toLocaleString()
                            : '$0'
                    };
                }));
            } catch (err) {
                console.error('Error fetching property media:', err);
            }

            this.totalPropertyValue = data.totalPropertyValue || 0;
            this.activeListingsCount = data.activeListingsCount || 0;
            this.closedDealsCount = data.closedDealsCount || 0;
            this.totalClosedAmount = data.totalClosedAmount || 0;
            this.isLoading = false;
        } else if (error) {
            console.error('Error loading initial data:', error);
            this.isLoading = false;
        }
    }

    showSale() {
        this.selectedType = 'Sale';
    }

    showRent() {
        this.selectedType = 'Rent';
    }

    goBack() {
        this.dispatchEvent(new CustomEvent('back'));
    }
}