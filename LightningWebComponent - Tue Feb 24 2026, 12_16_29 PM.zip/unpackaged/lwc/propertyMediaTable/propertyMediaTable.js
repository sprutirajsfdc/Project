import { LightningElement, api, track, wire } from 'lwc';
import getMediaRecords from '@salesforce/apex/PropertyMediatable.getMediaRecords';
import updateMedia from '@salesforce/apex/PropertyMediatable.updateMedia';
import deleteMedia from '@salesforce/apex/PropertyMediatable.deleteMedia';
import filePUT from '@salesforce/apex/S3ImageUploader.filePUT';  

import { getObjectInfo, getPicklistValues } from 'lightning/uiObjectInfoApi';
import PROPERTY_MEDIA_OBJECT from '@salesforce/schema/Property_Media__c';
import TAG_FIELD from '@salesforce/schema/Property_Media__c.Tag__c';
import uploadAndCreateMedia from '@salesforce/apex/PropertyMediatable.uploadAndCreateMedia';

import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class PropertyMediaTable extends LightningElement {
     @api recordId;
    @track mediaRecords = [];
    @track isModalOpen = false;
    @track selectedRecord = null;
    @track tagOptions = [];
    @track uploading = false;

    @wire(getObjectInfo, { objectApiName: PROPERTY_MEDIA_OBJECT })
    objectInfo;

    @wire(getPicklistValues, {
        recordTypeId: '$objectInfo.data.defaultRecordTypeId',
        fieldApiName: TAG_FIELD
    })
    wiredPicklistValues({ error, data }) {
        if (data) {
            this.tagOptions = data.values;
        } else if (error) {
            this.showToast('Error', 'Failed to load tag picklist values', 'error');
            console.error(error);
        }
    }

    connectedCallback() {
        this.fetchMedia();
    }

    fetchMedia() {
        getMediaRecords({ listingId: this.recordId })
            .then(result => {
                this.mediaRecords = result.map(media => {
                const videoId = this.extractYouTubeVideoId(media.Public_URL__c || media.os_ExternalLink__c);
                return {
                    ...media,
                    isYouTube: !!videoId,
                    thumbnailUrl: videoId ? `https://img.youtube.com/vi/${videoId}/hqdefault.jpg` : null,
                    embedUrl: videoId ? `https://www.youtube.com/embed/${videoId}` : null, // <--- add this
                    os_IsOnExpose__c: !!media.os_IsOnExpose__c,
                    os_IsOnPortalFeed__c: !!media.os_IsOnPortalFeed__c,
                    os_IsOnWebsite__c: !!media.os_IsOnWebsite__c,
                };
            });

            })
            .catch(error => {
                this.showToast('Error', 'Failed to load media records', 'error');
                console.error(error);
            });
    }

    extractYouTubeVideoId(url) {
        if (!url) return null;
        const regex = /(?:youtube\.com\/(?:.*v=|embed\/|shorts\/)|youtu\.be\/)([^&?/]+)/;
        const match = url.match(regex);
        return match ? match[1] : null;
    }

    handleEdit(event) {
        const id = event.target.dataset.id;
        this.selectedRecord = this.mediaRecords.find(m => m.Id === id);
        this.isModalOpen = true;
    }

    handleDelete(event) {
        const id = event.target.dataset.id;
        deleteMedia({ mediaId: id })
            .then(() => {
                this.showToast('Deleted', 'Media deleted successfully', 'success');
                this.fetchMedia();
            })
            .catch(error => {
                this.showToast('Error', 'Failed to delete media', 'error');
                console.error(error);
            });
    }

    handleCheckbox(event) {
    const id = event.target.dataset.id;
    const field = event.target.dataset.field;
    const checked = event.target.checked;

    const mediaToUpdate = this.mediaRecords.find(m => m.Id === id);
    if (mediaToUpdate) {
        const originalValue = mediaToUpdate[field]; // Store original value
        mediaToUpdate[field] = checked;
        
        updateMedia({ updatedMedia: mediaToUpdate })
            .then(() => {
                this.showToast('Updated', 'Media updated successfully', 'success');
                // No refresh needed since we updated locally
            })
            .catch(error => {
                mediaToUpdate[field] = originalValue; // Revert on error
                this.showToast('Error', 'Failed to update media', 'error');
                console.error(error);
            });
    }
}

    handleTagChange(event) {
        if (!this.selectedRecord) return;
        this.selectedRecord.Tag__c = event.detail.value;

        if (this.selectedRecord.Tag__c !== 'Virtual Tour') {
            this.selectedRecord.os_ExternalLink__c = null;
        }
    }

    handleExternalLinkChange(event) {
        if (!this.selectedRecord) return;
        this.selectedRecord.os_ExternalLink__c = event.target.value;
    }

    handleFileChange(event) {
        const file = event.target.files[0];
        if (!file) return;

        this.uploading = true;

        const reader = new FileReader();
        reader.onload = () => {
            const base64Data = reader.result.split(',')[1];
            this.uploadAndCreateMedia(file.name, base64Data);
        };
        reader.onerror = () => {
            this.uploading = false;
            this.showToast('Error', 'Failed to read file', 'error');
        };
        reader.readAsDataURL(file);
    }

    uploadAndCreateMedia(fileName, base64Data) {
        uploadAndCreateMedia({
            listingId: this.recordId,
            fileNameWithExtension: fileName,
            base64Data: base64Data,
            tag: this.selectedRecord?.Tag__c || 'Video'
        })
            .then(() => {
                this.uploading = false;
                this.showToast('Success', 'Media uploaded successfully', 'success');
                this.fetchMedia();
                this.isModalOpen = false;
            })
            .catch(error => {
                this.uploading = false;
                this.showToast('Error', 'Upload failed: ' + (error.body?.message || error.message), 'error');
                console.error(error);
            });
    }

    handleModalClose() {
        this.isModalOpen = false;
        this.selectedRecord = null;
        this.uploading = false;
    }

    handleSave() {
        if (!this.selectedRecord) return;

        updateMedia({ updatedMedia: this.selectedRecord })
            .then(() => {
                this.showToast('Success', 'Media saved successfully', 'success');
                this.fetchMedia();
                this.handleModalClose();
            })
            .catch(error => {
                this.showToast('Error', 'Failed to save media', 'error');
                console.error(error);
            });
    }

    handleRefresh() {
        this.fetchMedia();
        this.showToast('Refreshed', 'Media list refreshed', 'success');
    }

    get isVirtualTour() {
        return this.selectedRecord?.Tag__c === 'Virtual Tour';
    }

    showToast(title, message, variant = 'success') {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }
}