import { LightningElement, api, wire, track } from 'lwc';
import getPropertyMedia from '@salesforce/apex/PropertyMediaController.getPropertyMedia';
import getCDLink from '@salesforce/apex/PropertyMediaController.getCDLink';
import uploadMergedImageWithLogo from '@salesforce/apex/FileUploadControllerInGallery.uploadFileWaterMark';

import { refreshApex } from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { getRecord, getFieldValue, updateRecord } from 'lightning/uiRecordApi';

import Watermark_Enabled from '@salesforce/schema/Listing__c.Watermark_Enabled__c';
import sothebyslogo from '@salesforce/resourceUrl/watermrk';

export default class PropertyMediaCarousel extends LightningElement {
    @api recordId;
    @track mediaList = [];
    @track currentIndex = 0;
    @track isModalOpen = false;
    @track previewImage = '';
    @track isLoading = false;
    @track cdLinkList = [];
    @track watermarklogoImage = sothebyslogo;
    @track wiredMediaResult;

    @wire(getRecord, { recordId: "$recordId", fields: [Watermark_Enabled] })
    listing;

    get wmButtonLabel() {
        const wm_Enabled = getFieldValue(this.listing.data, Watermark_Enabled);
        return wm_Enabled ? 'Remove Watermark' : 'Add Watermark';
    }

    @wire(getPropertyMedia, { propertyId: '$recordId' })
    wiredMedia(result) {
        this.isLoading = true;
        this.wiredMediaResult = result;
        const { data, error } = result;

        if (data) {
            this.mediaList = data.map((file, index) => {
                const url = file.Public_URL;

                const image = {
                    ...file,
                    id: file.Id,
                    Public_URL: url,
                    Sort_On_Website: file.Sort_On_Website,
                    Tag: file.Tag__c || 'No Tag',
                    isYouTube: false,
                    isVideo: false,
                    embedUrl: '',
                    thumbnailUrl: ''
                };

                // YouTube Detection
                const youtubeMatch = url?.match(
                    /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/
                );

                if (youtubeMatch && youtubeMatch[1]) {
                    const videoId = youtubeMatch[1];
                    image.isYouTube = true;
                    image.embedUrl = `https://www.youtube.com/embed/${videoId}`;
                    image.thumbnailUrl = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
                } else if (url?.toLowerCase().endsWith('.mp4')) {
                    image.isVideo = true;
                }

                return image;
            }).sort((a, b) => a.Sort_On_Website - b.Sort_On_Website);
        } else if (error) {
            console.error('Error loading media:', error);
        }

        this.isLoading = false;
    }

    @wire(getCDLink, { propertyId: '$recordId' })
    wiredMediaLink({ data, error }) {
        if (data) {
            this.cdLinkList = data.map(item => ({
                ...item,
                versionData: `data:image/jpeg;base64,${item.versionData}`
            }));
        } else if (error) {
            console.error('Error loading media:', error);
        }
    }

    get currentImage() {
        return this.mediaList[this.currentIndex] || {};
    }

    get isImage() {
        const img = this.currentImage;
        return !img.isYouTube && !img.isVideo;
    }

    get noMedia() {
        return !this.isLoading && (!this.mediaList || this.mediaList.length === 0);
    }

    nextImage() {
        if (this.currentIndex < this.mediaList.length - 1) {
            this.currentIndex++;
        }
    }

    prevImage() {
        if (this.currentIndex > 0) {
            this.currentIndex--;
        }
    }

    handlePreview() {
        if (this.currentImage.isYouTube || this.currentImage.isVideo) {
            // Optional: allow video preview in modal
            this.previewImage = this.currentImage.Public_URL;
        } else {
            this.previewImage = this.currentImage.Public_URL;
        }
        this.isModalOpen = true;
    }

    closeModal() {
        this.isModalOpen = false;
        this.previewImage = '';
    }

    async handleWatermark() {
        this.isLoading = true;
        this.updateListing();

        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');

        for (const item of this.cdLinkList) {
            if (item?.WaterMark_URL) continue;

            try {
                const bgImg = await this.loadImage(item.versionData);
                const logoImg = await this.loadImage(sothebyslogo);

                canvas.width = bgImg.width;
                canvas.height = bgImg.height;

                ctx.clearRect(0, 0, canvas.width, canvas.height);
                ctx.drawImage(bgImg, 0, 0);

                const logoWidth = canvas.width * 0.4;
                const logoHeight = logoWidth * (logoImg.height / logoImg.width);

                ctx.drawImage(logoImg, canvas.width - logoWidth - 10, 10, logoWidth, logoHeight);

                const dataUrl = canvas.toDataURL('image/jpeg');
                const base64ImageData = dataUrl.split(',')[1];
                const fileSName = item.Public_URL.split('/').pop();

                await uploadMergedImageWithLogo({
                    fileName: 'WM_' + fileSName,
                    base64Data: base64ImageData,
                    recordId: this.recordId,
                    PropMediaId: item.PropMediaId
                });

                console.log('✅ Watermark Image uploaded successfully!');
            } catch (error) {
                console.error('❌ Error processing Watermark Image:', error);
            }
        }

        await new Promise(resolve => setTimeout(resolve, 2000));
        await refreshApex(this.wiredMediaResult);
        this.isLoading = false;
    }

    loadImage(src) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload = () => resolve(img);
            img.onerror = () => reject(new Error(`Failed to load image: ${src}`));
            img.src = src;
        });
    }

    updateListing() {
        const currentValue = getFieldValue(this.listing.data, Watermark_Enabled);
        const newValue = !currentValue;

        const fields = {
            Id: this.recordId,
            Watermark_Enabled__c: newValue,
        };

        updateRecord({ fields })
            .then(() => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Record updated',
                        variant: 'success',
                    })
                );
            })
            .catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error updating record',
                        message: error.body.message,
                        variant: 'error',
                    })
                );
            });
    }
}