import { LightningElement, track, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

import createAgencyRecord from '@salesforce/apex/AgencyRegistrationController.createAgencyRecord';

import { getObjectInfo, getPicklistValues } from 'lightning/uiObjectInfoApi';

import AGENCY_OBJECT from '@salesforce/schema/Agency_Details__c';
import AGENCY_TYPE_FIELD from '@salesforce/schema/Agency_Details__c.Agency_Type__c';
import COUNTRY_FIELD from '@salesforce/schema/Agency_Details__c.Country_of_Incorporation__c';
import BANK_NAME_FIELD from '@salesforce/schema/Agency_Details__c.Bank_Name__c';
import { loadScript } from 'lightning/platformResourceLoader';
import html2canvasLib from '@salesforce/resourceUrl/html2canvas';

export default class PartnerRegistration extends LightningElement {

    /* STEP CONTROL */
    @track step = 1;
    @track isSubmitted = false;

    /* RECORD INFO */
    recordId;
    referenceNumber;
    formattedCreatedDate;

    /* STORE FORM DATA */
    formData = {};

    /* OBJECT INFO */
    @wire(getObjectInfo, { objectApiName: AGENCY_OBJECT })
    agencyInfo;

    /* PICKLIST OPTIONS */
    @track agencyTypeOptions = [];
    @track countryOptions = [];
    @track bankOptions = [];

    /* AGENCY TYPE */
    @wire(getPicklistValues, {
        recordTypeId: '$agencyInfo.data.defaultRecordTypeId',
        fieldApiName: AGENCY_TYPE_FIELD
    })
    wiredAgencyType({ data, error }) {
        if (data) this.agencyTypeOptions = data.values;
        if (error) console.error(error);
    }

    /* COUNTRY */
    @wire(getPicklistValues, {
        recordTypeId: '$agencyInfo.data.defaultRecordTypeId',
        fieldApiName: COUNTRY_FIELD
    })
    wiredCountryValues({ data, error }) {
        if (data) this.countryOptions = data.values;
        if (error) console.error(error);
    }

    /* BANK */
    @wire(getPicklistValues, {
        recordTypeId: '$agencyInfo.data.defaultRecordTypeId',
        fieldApiName: BANK_NAME_FIELD
    })
    wiredBankValues({ data, error }) {
        if (data) this.bankOptions = data.values;
        if (error) console.error(error);
    }

    /* HANDLE INPUT */
    handleChange(event) {
        const field = event.target.dataset.field;
        const value = event.target.value;
        this.formData[field] = value;
    }

    /* FILE UPLOAD SUCCESS */
    handleUploadFinished(event) {
        const uploadedFiles = event.detail.files;

        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Success',
                message: uploadedFiles.length + ' file(s) uploaded successfully',
                variant: 'success'
            })
        );
    }

    /* FINAL SUBMIT (NO RECORD CREATION HERE) */
    handleFinalSubmit() {
        this.finishSubmission();
    }
    

    /* SUCCESS LOGIC */
    finishSubmission() {

        this.isSubmitted = true;

        const now = new Date();

        this.formattedCreatedDate = now.toLocaleString('en-US',{
            month:'short',
            day:'numeric',
            year:'numeric',
            hour:'2-digit',
            minute:'2-digit'
        });

        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Success',
                message: 'Registration Submitted Successfully',
                variant: 'success'
            })
        );
    }

    /* NAVIGATION */

    nextStep() {

        // 🔥 IMPORTANT: Create record BEFORE upload step
        if (this.step === 3 && !this.recordId) {
console.log('FORM DATA => ', JSON.stringify(this.formData));
           createAgencyRecord({ formData: this.formData })
            
            .then(result => {

                this.recordId = result.Id;
                this.referenceNumber = result.Name;

                this.step++; // Move to Step 4

            })
            .catch(error => {

                let message = 'Error creating record';

                if(error.body && error.body.message){
                    message = error.body.message;
                }

                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error',
                        message: message,
                        variant: 'error'
                    })
                );

            });

        } else {

            if (this.step < 5) {
                this.step++;
            }

        }
    }

    prevStep() {
        if (this.step > 1) {
            this.step--;
        }
    }
    downloadImage() {

    const element = this.refs.template;

    if (!element) {
        console.error('Template not found');
        return;
    }

    html2canvas(element).then(canvas => {

        const link = document.createElement('a');
        link.download = 'Agency_Registration.png';
        link.href = canvas.toDataURL('image/png');
        link.click();

    });

}

    /* STEP VISIBILITY */
    get isStep1() { return this.step === 1 && !this.isSubmitted; }
    get isStep2() { return this.step === 2 && !this.isSubmitted; }
    get isStep3() { return this.step === 3 && !this.isSubmitted; }
    get isStep4() { return this.step === 4 && !this.isSubmitted; }
    get isStep5() { return this.step === 5 && !this.isSubmitted; }

    /* REVIEW DATA */
    get Agency_Name__c() { return this.formData.Agency_Name__c; }
    get Agency_Type__c() { return this.formData.Agency_Type__c; }
    get Country_of_Incorporation__c() { return this.formData.Country_of_Incorporation__c; }
    get City__c() { return this.formData.City__c; }
    get Personal_Name__c() { return this.formData.Personal_Name__c; }
    get Phone__c() { return this.formData.Phone__c; }
    get Email_Address__c() { return this.formData.Email_Address__c; }

    /* PROGRESS BAR */
    get progressStyle() {
        if (this.isSubmitted) return 'width:100%';
        return `width:${this.step * 20}%`;
    }

    /* STEP CSS */
    get step1Class() { return this.step === 1 ? 'active' : this.step > 1 ? 'completed' : ''; }
    get step2Class() { return this.step === 2 ? 'active' : this.step > 2 ? 'completed' : ''; }
    get step3Class() { return this.step === 3 ? 'active' : this.step > 3 ? 'completed' : ''; }
    get step4Class() { return this.step === 4 ? 'active' : this.step > 4 ? 'completed' : ''; }
    get step5Class() { return this.step === 5 ? 'active' : ''; }

}